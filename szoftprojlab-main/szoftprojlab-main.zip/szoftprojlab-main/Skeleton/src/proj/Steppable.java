

/** 
 * A j�t�k folyam�n l�pni k�pes objektumokat reprezent�lja
 */
public interface Steppable
{
	/** 
	 *A l�pni k�pes objektumokat l�pteti
	 */
	public default void Step(){}
}
