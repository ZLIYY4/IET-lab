/** 
 * A jtk kezdett s vgt kezel osztly
*/
public class Game
{
	/** 
	 *  Ellen�rzi, hogy megvan-e az adott virolgusnak a megfelel szm 
	 *  genetikai kdja, az adott virolgusnl lv genetikai kdok szmt 
	 *  kapja meg paramterknt
	 *  @param codeNumber hny darab code-dal rendelkezik a virolgus
	 */
	public static void EndGame(int codeNumber)
	{
		if(codeNumber==4)
		{
			System.out.println("Vege a jateknak!");
		}

		
	}
}
