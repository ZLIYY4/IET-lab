import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/** 
 * A p�lya egy �p�t�eleme, amire a virol�gus l�phet.
 * */
public class Field
{
	/**
	 * Egy id amivel tudjuk az adott mez�t a ki�r�sn�l azonos�tani a felhaszn�l� fogja hasszn�lni
	 */
	String id;
	/**
	 * A mez�n tart�zk�d� virologusok list�ja
	 */
	private List<Virologist> virologist;
	/** 
	 *  Az adott j�t�kmez� szomsz�dos mez�inek list�ja
	 */
	private List<Field> neighbors;
	/**
	 * Visszaadja, hogy melyik virologusok vannak az adott mez�n.
	 * @return virologist Lista hogy milyen virol�gusok vannak a mez�n
	 */
	public List<Virologist> getVirologist(){
		return virologist;
	}
	/**
	 * Getter a szomszedok lekerdezesere.
	 * @return
	 */
	public List<Field> getNeighbors(){
		return neighbors;
	}
	public void addNeighbour(Field f) {
		neighbors.add(f);
	}
	/**
	 * Az oszt�ly konstruktora.
	 * L�trehozza a list�kat, amikben t�rolva lesz a szomsz�dos mez�
	 * �s a virol�gus ami rajta �ll
	 */
	public Field() {
		virologist=new ArrayList<Virologist>();
		neighbors = new ArrayList<Field>();
		id="field"+(int)(Math.random()*1000);
	}
	/**
	 * A param�terk�nt kapott mez�t be�ll�tja szomsz�dnak
	 * @param f melyik mez� a szomsz�dja
	 */
	public void AddField(Field f)
	{
		neighbors.add(f);
	}
	/** 
	 *  A virologists list�ba a param�ternek kapott Virologist-et viszi fel
	 *  @param v Megkapja, hogy melyik virologus l�pett r�
	 */
	public void Accept(Virologist v)
	{
		//System.out.println("\tAccept(v) Virol�gus hozz�ad�dik egy mez�h�z");
		virologist.add(v);
		v.setFields(this);
	}
	
	public String getid()
	{
		return id;
	}
	
	public void setid(String nid)
	{
		 id=nid;
	}
	/** 
	 *  A param�ternek kapott Virologist-et t�rli a virologists list�b�l
	 *  @param v Megkapja, hogy melyik virol�gus l�pett le a mez�r�l, melyiket kell t�rl�lni a list�b�l
	 */
	public void Remove(Virologist v)
	{
		//System.out.println("\tRemove(v) Az adott mez� elhagyja a Virologus");
		virologist.remove(v);
	}
	
	/** 
	 *  A param�ternek kapott Virologist-nek ad valamit, 
	 *  a lesz�rmazottak fel�l defini�lj�k (ez a valami, lehet felszerel�s, code, anyag)
	 */
	public void Use(Virologist v)
	{
	}
	
	/** 
	 * Visszat�r egy v�letlenszer�en v�lasztott szomsz�dos mez�vel
	 * @return a v�letlenszer� szomsz�dos mez�
	 */
	public Field GetRandomNeighbor()
	{
		//System.out.println("\tGetRandomNeighbor() Egy random szomsz�dos mez�t kapunk meg a mez�t�l");
        Random rand = new Random();
        //System.out.println("\tGetRandomNeighbor() Field return");
        return neighbors.get(rand.nextInt(neighbors.size()));
	}
}
