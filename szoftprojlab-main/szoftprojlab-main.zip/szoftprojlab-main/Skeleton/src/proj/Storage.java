import java.util.ArrayList;
import java.util.List;

/** 
 * Egy speci�lis mez�, amire a virol�gus l�phet 
 * Ez a mez� tartalmazhat anyagokat, 
 * amik sz�ks�gesek az �gensek elk�sz�t�shez.
*/
public class Storage extends Field
{
	/**
	 * A mez�n l�ve� anyagok list�ja
	 */
	List<Material> mat;
	/**
	 * Storage konstruktora
	 * l�trehozza a list�t
	 */
	public  Storage() {
		mat = new ArrayList<Material>();
	}
	/**
	 * Materi�l hozz�ada�sa a rakt�rhoz
	 */
	public void matAdd(Material m) 
	{
		//System.out.println("\tmatAdd(m)  Anyag felv�tele rakt�rba");
		mat.add(m);
		//System.out.println("\tmatAdd(m)  void return");
	}
	/** 
	 * A param�terk�nt kapott virol�gusnak �tadja a mat v�ltoz� tartalm�t
	 * Ha MaciEffect- van rajta, akkor a mez�r�l mindent elt�ntett, megesik
	 *@param v Melyik virol�gus vesszi fele a rakt�rb�l a dolgokat
	 */
	@Override
	public void Use(Virologist v)
	{
		//System.out.println("\tUse(v) Anyag felv�tel rakt�rb�l.");
		EffectVisitor visit= new EffectVisitor();
		for(int i = 0;i<v.getEffect().size();i++) {
			if(v.getEffect().get(i).Accept(visit)==7)
			{
				mat.clear();
				return;
			}
		}
		while (!mat.isEmpty() && v.getinventory().Getmax_Material() != v.getinventory().getMaterial().size()) {
			v.PickupMaterial(mat.get(0));
		}
		//System.out.println("\tUse(v) void return");
	}
	
	/** 
	 * A mat v�ltoz� list�b�l t�rli a param�terk�nt kapott Material-t(anyagot)
	 * @param m Melyik anyag legyen t�r�lve
	 */
	public void Remove(Material m)
	{
		//System.out.println("\tRemove(m) Anyag t�rl�se a rakt�rb�l.");
		if(!mat.remove(m)) System.out.println("Remove(m) Hiba,nem tudom ezt a Materialt torolni mert nincsen a listaban!");
		else mat.remove(m);
		//System.out.println("\tRemove(m) void return");
	}
}
