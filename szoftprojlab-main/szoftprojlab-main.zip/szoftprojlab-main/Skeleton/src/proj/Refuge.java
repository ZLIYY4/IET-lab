


/** 
 * Egy speci�lis mez�, amire a virol�gus l�phet. Ez a mez� tartalmazhat felszerel�st.
 */
public class Refuge extends Field
{
	/** 
	 * Az adott j�t�kmez�n l�v� felszerel�s
	 */
	private Gear gear;
	/**
	 * Gear getter
	 * @return gear
	 */
	public Gear getGear() {
		return gear;
	}
	/**
	 * gear settere
	 * be�ll�tja, hogy milyen felszerel�s van az adott mez�n
	 */
	public void setGear(Gear g) 
	{
		//System.out.println("\tsetGear(g)  �vohelyhez felszerel�s hozz�ad�sa.");
		gear=g;
	}
	/** 
	 * A param�terk�nt kapott virol�gusnak �tadja a gear v�ltoz� tartalm�t
	 * Ha Macieffect van rajta nem tud felszerel�st felvenni �gy itt nem t�rt�nik, semmi ha olyan effect van ratja
	 * @param v Melyik virol�gus veszi fel a felszerel�st
	 */
	@Override
	public void Use(Virologist v)
	{
		EffectVisitor visit= new EffectVisitor();
		for(int i = 0;i<v.getEffect().size();i++) {
			if(v.getEffect().get(i).Accept(visit)==7)
			{
				return;
			}
		}
		int gearSize = v.getinventory().Gearssize();
		int maxGear = v.getinventory().Getmax_Gear();
		//System.out.println("\tUse(v) Felszerel�s felv�tele a �vohelyr�l.");
		if(gearSize<=maxGear && gear!=null)
			gear.TakeGear(v);
	}
	
	/** 
	 * A gear v�ltoz� �rt�k�t null-ra v�ltoztatja, felszerl�s elv�ttele a mez�r�l
	 */
	public void Remove()
	{
		//System.out.println("\tRemove() Felszerel�s elv�tol�t�sa a �vohelyb�l");
		this.gear=null;
	}
}
